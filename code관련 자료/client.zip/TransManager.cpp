#include "TransManager.h"

TransManager* TransManager::pInstance = nullptr;